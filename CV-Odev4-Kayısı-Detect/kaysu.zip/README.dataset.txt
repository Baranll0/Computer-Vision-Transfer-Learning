# KayısıDetect > 2024-11-10 8:21pm
https://universe.roboflow.com/roboflowdemo-fhqqx/kayisidetect

Provided by a Roboflow user
License: CC BY 4.0

